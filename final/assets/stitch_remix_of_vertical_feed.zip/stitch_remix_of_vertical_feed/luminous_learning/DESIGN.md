---
name: Luminous Learning
colors:
  surface: '#121416'
  surface-dim: '#121416'
  surface-bright: '#37393b'
  surface-container-lowest: '#0c0e10'
  surface-container-low: '#1a1c1e'
  surface-container: '#1e2022'
  surface-container-high: '#282a2c'
  surface-container-highest: '#333537'
  on-surface: '#e2e2e5'
  on-surface-variant: '#d0c6ab'
  inverse-surface: '#e2e2e5'
  inverse-on-surface: '#2f3133'
  outline: '#999077'
  outline-variant: '#4d4732'
  surface-tint: '#e9c400'
  primary: '#fff6df'
  on-primary: '#3a3000'
  primary-container: '#ffd700'
  on-primary-container: '#705e00'
  inverse-primary: '#705d00'
  secondary: '#4ce346'
  on-secondary: '#003a03'
  secondary-container: '#04b71a'
  on-secondary-container: '#003f03'
  tertiary: '#fff4ef'
  on-tertiary: '#4d2600'
  tertiary-container: '#ffd1af'
  on-tertiary-container: '#914d00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe16d'
  primary-fixed-dim: '#e9c400'
  on-primary-fixed: '#221b00'
  on-primary-fixed-variant: '#544600'
  secondary-fixed: '#75ff68'
  secondary-fixed-dim: '#4ce346'
  on-secondary-fixed: '#002201'
  on-secondary-fixed-variant: '#005306'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#121416'
  on-background: '#e2e2e5'
  surface-variant: '#333537'
typography:
  h1:
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h2:
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h3:
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: '0'
  body-lg:
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-caps:
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 20px
  margin: 24px
---

## Brand & Style
This design system is built to transform a cinematic experience into an energetic, educational discovery platform. It shifts away from passive consumption toward active engagement and "edutainment." The brand personality is optimistic, scholarly yet accessible, and intensely focused on clarity.

The visual style utilizes a **High-Contrast / Bold** approach. By pairing a deep, non-black charcoal background with high-visibility accents, the interface achieves a "glowing" effect that directs the user’s eye to key learning touchpoints without the eye strain of pure pitch-black themes. It balances technical precision with a playful, vibrant energy suitable for a modern learning environment.

## Colors
The palette is engineered for maximum legibility and high energy. The primary background (#1A1C1E) provides a sophisticated, "near-black" canvas that allows the vibrant accents to pop.

- **Primary Gold (#FFD700):** Used for primary actions, progress indicators, and "aha!" moments. It symbolizes intelligence and achievement.
- **Fresh Lime (#32CD32):** Reserved for success states, completed modules, and secondary highlights. It provides a refreshing contrast to the warmth of the gold.
- **Warm Orange (#FF8C00):** Utilized for interactive elements that require attention but aren't the main CTA, such as "Read More" or "Related Topics."
- **Surfaces:** Secondary surfaces use #25282B to create soft depth against the main background, ensuring the UI doesn't feel flat.

## Typography
This design system exclusively employs **Space Grotesk** to maintain a technical, cutting-edge aesthetic that feels both futuristic and scholarly. The geometric nature of the typeface ensures that even at small sizes, educational metadata remains highly readable.

Headlines should be set with tight leading and slight negative tracking to give a "bold poster" feel. Body text relies on generous line heights to facilitate long-form reading during deep-dive learning sessions. The use of uppercase labels provides a structural rhythm to the layout, distinguishing between content and UI controls.

## Layout & Spacing
The layout follows a **Fluid Grid** model with a base-8 rhythm. This ensures a consistent vertical cadence across all screen sizes. 

Margins are kept relatively wide (24px) to provide "breathing room," preventing the high-contrast elements from feeling cluttered. Gutters are optimized at 20px to maintain clear separation between educational cards and content modules. The system prioritizes a "content-first" hierarchy where information is grouped into logical, digestible clusters.

## Elevation & Depth
To maintain the high-energy feel, this design system avoids heavy shadows, which can feel "muddy" on dark backgrounds. Instead, it utilizes **Tonal Layers** and **Low-Contrast Outlines**.

- **Level 0:** Base Background (#1A1C1E).
- **Level 1:** Surface Cards (#25282B) with a subtle 1px border (#3A3D42) to define boundaries.
- **Level 2:** Active/Hover states, which use a faint glow (Primary Gold at 10% opacity) rather than a traditional drop shadow.
- **Visual Stacking:** Depth is conveyed through color saturation; more important elements are brighter and more saturated, while background elements are more muted.

## Shapes
The shape language is **Rounded**, striking a balance between the precision of the typography and the friendliness of an educational tool. 

Standard components (Cards, Modals) use a 0.5rem radius, while "actionable" items like buttons and chips utilize a fully rounded **Pill-shape** (1rem or greater). This distinction helps users immediately identify what is an interactive control versus what is a piece of content.

## Components
- **Buttons:** Primary buttons are pill-shaped, filled with Primary Gold, using black text for maximum contrast. Secondary buttons use the Fresh Lime outline.
- **Educational Chips:** Small, pill-shaped tags used for categories (e.g., "History," "Directing Styles"). Use a subtle #25282B background with Gold or Lime text.
- **Discovery Cards:** Large-format cards with a 1px border. The footer of the card should house metadata in the `label-caps` style.
- **Progress Indicators:** Use the Primary Gold for active progress bars and the Secondary Lime for completed sections.
- **Input Fields:** Minimalist containers with a 1px bottom border that transforms into a 2px Gold border upon focus, accompanied by a subtle upward shift of the label.
- **Feedback Toasts:** High-visibility bars using the Secondary Lime for "Correct/Success" and Warm Orange for "Hints/Alerts."