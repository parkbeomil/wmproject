---
name: Modern Scholastic
colors:
  surface: '#faf9f9'
  surface-dim: '#dadada'
  surface-bright: '#faf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e3e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#4d4732'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f0f0'
  outline: '#7e775f'
  outline-variant: '#d0c6ab'
  surface-tint: '#705d00'
  primary: '#705d00'
  on-primary: '#ffffff'
  primary-container: '#ffd700'
  on-primary-container: '#705e00'
  inverse-primary: '#e9c400'
  secondary: '#006e2f'
  on-secondary: '#ffffff'
  secondary-container: '#6bff8f'
  on-secondary-container: '#007432'
  tertiary: '#5f5e5e'
  on-tertiary: '#ffffff'
  tertiary-container: '#dcd9d9'
  on-tertiary-container: '#605f5e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffe16d'
  primary-fixed-dim: '#e9c400'
  on-primary-fixed: '#221b00'
  on-primary-fixed-variant: '#544600'
  secondary-fixed: '#6bff8f'
  secondary-fixed-dim: '#4ae176'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#005321'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1c1b1b'
  on-tertiary-fixed-variant: '#474746'
  background: '#faf9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e3e2e2'
typography:
  h1:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h2:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h3:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: '8'
  container-margin: 32px
  gutter: 24px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

This design system is built for a premium educational experience, blending the intellectual rigor of a modern library with the high-energy engagement of cinema. The personality is "Enlightened, Precise, and Vibrant." It targets lifelong learners and students who value curated discovery over mindless scrolling.

The visual style utilizes a **Modern Minimalism** approach with a **High-Contrast** accent strategy. The UI stays out of the way of the film content, using generous whitespace to signify an "academic" or "gallery" environment. Bold typography provides a sense of authority and structure, while the vibrant primary colors prevent the experience from feeling cold or institutional.

## Colors

The palette is anchored by a clean, professional neutral foundation. Instead of clinical whites or warm sepia tones, we utilize a refined palette derived from **Cool Neutral (#C2C2C2)** for the main canvas and structural elements. This provides a crisp, contemporary quality that ensures maximum focus on content and reinforces the scholastic theme.

**Warm Yellow (#FFD700)** is the primary call-to-action color, symbolizing illumination and "eureka" moments. It should be used for primary buttons and high-priority discovery markers. **Fresh Green (#22C55E)** serves as a secondary accent, specifically reserved for educational progress, "completed" states, and scholarly achievement badges. Text and structural lines use a deep charcoal **#1A1A1A** to ensure maximum legibility and a sophisticated, modern feel.

## Typography

The design system exclusively utilizes **Space Grotesk** to lean into a technical yet approachable aesthetic. Its geometric quirks provide the "modern" edge required for a film-centric app, while its clarity maintains the "academic" standard.

Headlines should use tight tracking and heavy weights to create a strong visual hierarchy. Body copy uses a slightly more relaxed line-height to ensure comfort during longer reads of film synopses or educational curricula. Label styles should be used for metadata (e.g., "Runtime," "Subject," "Difficulty Level") and are most effective when rendered in uppercase with slight tracking to provide a structural, "catalogued" look.

## Layout & Spacing

This design system employs a **Fixed Grid** philosophy for desktop and tablet, ensuring that content density remains controlled and legible. A 12-column grid is used with generous 24px gutters to allow the UI to "breathe."

The rhythm is based on an **8px base unit**. Margins are intentionally wide (32px+) to frame the content like an exhibit. Vertical rhythm should prioritize large "stacks" (48px) between major sections (e.g., "Trending Documentaries" vs "Your Learning Path") to maintain a clear mental model of the information architecture.

## Elevation & Depth

To maintain a "clean and academic" look, this design system avoids heavy shadows. Depth is primarily communicated through **Tonal Layers** and **Low-Contrast Outlines** anchored in the Neutral Gray palette.

1.  **Background:** A bright, neutral surface (e.g., #FFFFFF or a very light gray tint).
2.  **Surface (Cards/Containers):** Elevated containers use lighter variants with a subtle 1px border of **Cool Neutral (#C2C2C2)** at low opacity.
3.  **Active/Hover:** Use a slight ambient shadow (4px blur, 5% opacity black) to indicate interactivity.

Floating elements, such as video players or modals, should use a "Deep Elevation" consisting of a 16px blur with 10% opacity, ensuring they sit clearly above the educational content without feeling "heavy."

## Shapes

The shape language is defined as **Rounded**, striking a balance between the precision of a grid and the friendliness of a modern app. 

Standard components like input fields and film cards use a **0.5rem (8px)** corner radius. Buttons and progress indicators utilize the **rounded-xl (1.5rem)** setting to create a softer, more inviting touchpoint. Film posters within cards should maintain the 0.5rem radius to look like physical media items.

## Components

### Buttons
- **Primary:** Warm Yellow (#FFD700) with Black (#1A1A1A) text. High-contrast and bold.
- **Secondary:** Fresh Green (#22C55E) with White text. Used for "Start Lesson" or "Save Progress."
- **Tertiary/Ghost:** 1px border of #1A1A1A or Cool Neutral (#C2C2C2) with no fill.

### Film Cards
Cards should feature a 16:9 or 2:3 aspect ratio image container. Metadata (Title, Subject, Duration) is placed below the image. A "Learning Progress" bar (Green #22C55E) should be docked at the bottom of the image for films currently being viewed.

### Progress & Status
Progress bars are sleek, using a 4px height. The background of the bar is a 10% opacity version of the accent color. Success states and "Mastered" badges always utilize the Fresh Green (#22C55E).

### Input Fields
Inputs are minimal: Light tinted background, 1px Cool Neutral (#C2C2C2) border, and Space Grotesk text. On focus, the border transitions to a 2px stroke of Warm Yellow (#FFD700).

### Educational Chips
Small, pill-shaped tags used for categories (e.g., "History," "Physics"). Use a muted gray background (derived from #C2C2C2) with #1A1A1A text to keep them subordinate to the primary action buttons.